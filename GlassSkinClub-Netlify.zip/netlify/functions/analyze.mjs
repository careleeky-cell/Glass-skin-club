// Glass Skin Club — selfie skin analysis (cosmetic, not medical).
// The Anthropic API key lives only here, in the Netlify environment variable ANTHROPIC_API_KEY.
// Photos are analysed in memory and never stored.

const MODEL = process.env.ANTHROPIC_MODEL || "claude-sonnet-5";

const PROMPT = `You are a cosmetic skincare advisor for a Korean-skincare club in Qatar. The attached image is a selfie the user took to get skincare product suggestions.
Look ONLY at visible, cosmetic skin characteristics. Do not diagnose disease, do not guess age, ethnicity, identity or anything about the person beyond visible skin.
First judge photo quality. If there is no clear human face, or it is too dark/blurry, heavily filtered, or covered by heavy makeup, set "ok": false and give a short retake tip.
Otherwise estimate:
- "skin": one of "oily","combo","dry","normal","sensitive" (visible shine, dry flakes, visible redness/irritation; use "combo" for shiny T-zone with drier cheeks).
- "scores": 0-100 visible intensity for each of: acne (active spots/blackheads), pores (enlarged pores/shine), dry (dehydration lines, flaking, dullness from dryness), spots (dark spots, marks, uneven tone), aging (fine lines, loss of firmness), redness (redness/visible sensitivity).
- "obs_ar": 3 short, kind, specific observations in Arabic (feminine address), cosmetic language only.
- "obs_en": the same 3 in English.
- "doctor": true only if something looks like it needs a dermatologist (e.g. severe or cystic acne, an unusual mole, open wounds, a rash); otherwise false.
Reply with ONLY this JSON, no other text:
{"ok":true,"retake_ar":"","retake_en":"","skin":"combo","scores":{"acne":0,"pores":0,"dry":0,"spots":0,"aging":0,"redness":0},"obs_ar":["","",""],"obs_en":["","",""],"doctor":false}`;

const json = (status, obj) => new Response(JSON.stringify(obj), { status, headers: { "content-type": "application/json", "cache-control": "no-store" } });

export default async (req) => {
  if (req.method !== "POST") return json(405, { error: "method" });
  // only accept calls coming from this site's own pages
  const origin = req.headers.get("origin") || "";
  const host = req.headers.get("host") || "";
  if (origin && !origin.endsWith(host)) return json(403, { error: "origin" });
  if (!process.env.ANTHROPIC_API_KEY) return json(500, { error: "no_key" });

  let image;
  try { ({ image } = await req.json()); } catch { return json(400, { error: "body" }); }
  if (typeof image !== "string" || image.length < 1000 || image.length > 4_000_000) return json(400, { error: "image" });

  const r = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-api-key": process.env.ANTHROPIC_API_KEY,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: MODEL,
      max_tokens: 900,
      messages: [{ role: "user", content: [
        { type: "image", source: { type: "base64", media_type: "image/jpeg", data: image } },
        { type: "text", text: PROMPT },
      ] }],
    }),
  });
  if (r.status === 429) return json(429, { error: "busy" });
  if (!r.ok) return json(502, { error: "upstream", status: r.status });

  const data = await r.json();
  const text = (data.content || []).filter(b => b.type === "text").map(b => b.text).join("");
  const m = text.match(/\{[\s\S]*\}/);
  if (!m) return json(502, { error: "parse" });
  try { return json(200, JSON.parse(m[0])); } catch { return json(502, { error: "parse" }); }
};

// public path + a simple per-visitor rate limit (10 analyses per minute)
export const config = {
  path: "/api/analyze",
  rateLimit: { windowLimit: 10, windowSize: 60, aggregateBy: ["ip", "domain"] },
};
